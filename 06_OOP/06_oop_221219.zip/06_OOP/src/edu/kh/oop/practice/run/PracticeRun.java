package edu.kh.oop.practice.run;

import edu.kh.oop.practice.model.service.BookService;

public class PracticeRun {

	public static void main(String[] args) {
		BookService bs = new BookService();
		bs.practice();
	}

}
