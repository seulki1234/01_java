package edu.kh.oop.cls.run;

import edu.kh.oop.cls.model.service.ClsService;

public class ClsRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClsService clsService = new ClsService();
		
		clsService.ex3();
		
	}

}
