package edu.kh.array.practice;

public class PracticeRun {
	public static void main(String[] args) {
		
		ArrayPractice ap = new ArrayPractice();
		
//		ap.practice2();
//		ap.practice5();
//		ap.practice7();
//		ap.practice8();
//		ap.practice11();
//		ap.practice13();
		ap.practice14();
	}
}
