package edu.kh.collection.run;

import edu.kh.collection.model.service.MapService;

public class MapRun {

	public static void main(String[] args) {
		
		MapService service = new MapService();
		service.ex3();
	
	
	}

}
