package edu.kh.network.run;

import edu.kh.network.model.service.TCPClient;

public class ClientRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TCPClient client = new TCPClient();
		client.clientStart();
	}

}
