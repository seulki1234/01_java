package edu.kh.io.run;

import edu.kh.io.model.service.IOService;

public class IORun {

	public static void main(String[] args) {
		
		IOService ioservice = new IOService();
		//ioservice.output1();
		// ioservice.input1();
		//ioservice.output2();
		ioservice.input2();
	}
}
