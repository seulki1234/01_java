package edu.kh.control.loop;

public class LoopRun {

	public static void main(String[] args) {
		ForExample forEx = new ForExample();
		
		//forEx.ex13();
		
		WhileExample whileEx = new WhileExample();
		whileEx.ex4();
	}

}
