package edu.kh.control.branch;

public class BranchRun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BranchExample ex = new BranchExample();
		ex.ex4();
	}

}
