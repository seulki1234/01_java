package edu.kh.control.condition;

public class ConditionRun { // 실행용 클래스

	public static void main(String[] args) {
		ConditionExample condition 
			= new ConditionExample();
		
		//condition.ex1();
		//condition.ex6();
		
		SwitchExample switchEx = new SwitchExample();
		
		switchEx.ex1();

	}

}
