package edu.kh.poly.run;

import edu.kh.poly.model.service.PolyService;

public class PloyRun {

	public static void main(String[] args) {
		PolyService ps = new PolyService();
		//ps.ex5();
		
		String[] sArr = {"빨강", "노랑", "파랑"};
		for(int i= 0; i<sArr.length; i++){
			System.out.println(sArr);

			}
	}

}
