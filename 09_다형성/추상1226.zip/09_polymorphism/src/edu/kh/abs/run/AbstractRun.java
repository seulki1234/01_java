package edu.kh.abs.run;

import edu.kh.abs.model.service.AbstractService;

public class AbstractRun {

	public static void main(String[] args) {
		AbstractService abs = new AbstractService();
		abs.ex1();

	}

}
