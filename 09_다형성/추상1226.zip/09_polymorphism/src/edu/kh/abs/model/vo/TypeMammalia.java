package edu.kh.abs.model.vo;
					
public abstract class TypeMammalia extends Animal { // 포유류
	
	// 포유류 특징
	public abstract void breastfeed(); // 수유를하다
	
}
