package edu.kh.abs.model.vo;

public abstract class TypePisces extends Animal { // 어류
	public abstract void swimming();
}
