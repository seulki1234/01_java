package edu.kh.inter.run;

import edu.kh.inter.model.service.InterfaceService;

public class InterfaceRun {

	public static void main(String[] args) {
		InterfaceService inter = new InterfaceService();
		inter.ex1();
	}

}
