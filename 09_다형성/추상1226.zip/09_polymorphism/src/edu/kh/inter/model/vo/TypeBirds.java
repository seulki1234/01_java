package edu.kh.inter.model.vo;

public abstract class TypeBirds extends Animal{ // 조류
	public void fly() {
		System.out.println("조류는 날 수 있어요~");
	}
}
