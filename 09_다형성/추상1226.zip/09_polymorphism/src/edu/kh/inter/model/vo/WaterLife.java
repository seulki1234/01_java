package edu.kh.inter.model.vo;

public interface WaterLife {
	
	public abstract void water();
}
