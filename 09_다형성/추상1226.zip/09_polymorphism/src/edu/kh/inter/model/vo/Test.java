package edu.kh.inter.model.vo;

public interface Test {
	
	public abstract void test();
}
