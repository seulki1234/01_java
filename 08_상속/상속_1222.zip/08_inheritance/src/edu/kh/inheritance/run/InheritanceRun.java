package edu.kh.inheritance.run;

import edu.kh.inheritance.model.service.InheritanceService;

public class InheritanceRun {

	public static void main(String[] args) {
		InheritanceService service = new InheritanceService();
	
		service.ex3();
	}

}
