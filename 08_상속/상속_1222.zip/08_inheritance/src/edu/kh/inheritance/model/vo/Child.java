package edu.kh.inheritance.model.vo;

public class Child extends Parent{

	@Override
	public void method() {
		System.out.println("오버라이딩~");
	}
	
	
}
